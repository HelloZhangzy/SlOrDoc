//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "mt_32.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int icdev;//�豸���
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//��������
//---------------------------------------------------------------------------
void __fastcall TForm1::Button_connectClick(TObject *Sender)
{
        if(icdev > 0)
        {
                HB_Close();
                icdev = NULL;
        }

        icdev = (int)HB_Open();
        if(icdev > 0)
        {
                infolist->AddItem("�������ӳɹ�", 0);
        }
        else
        {
                infolist->AddItem("��������ʧ��", 0);
        }
}
//M1��
//---------------------------------------------------------------------------
void __fastcall TForm1::Button_m1Click(TObject *Sender)
{
        int st = 0;
        unsigned char key[10] = {0};
        unsigned char data[40] = {0};
        unsigned char temp[40] = {0};
        unsigned long read_value = 0;

        st = rf_card((HANDLE)icdev, 0, temp);
        if(st == 0)
        {
                hex_asc(temp, data, 4);
                infolist->AddItem("Ѱ���ɹ�",0);
                infolist->AddItem(AnsiString((char *)data), 0);
        }
        else
        {
                infolist->AddItem("Ѱ��ʧ��",0);
                return;
        }

        asc_hex("FFFFFFFFFFFF", key, 12);
        st = rf_authentication_key((HANDLE)icdev, 0, 48, key);
        if(st == 0)
        {
                infolist->AddItem("У���12�����ɹ�",0);
        }
        else
        {
                infolist->AddItem("У���12����ʧ��",0);
                return;
        }

        memset(data, 0, sizeof(data));
        asc_hex("00112233445566778899AABBCCDDEEFF", data, 32);
        st = rf_write((HANDLE)icdev, 48, data);
        if(st == 0)
        {
                infolist->AddItem("д���ݳɹ�",0);
        }
        else
        {
                infolist->AddItem("д����ʧ��",0);
                return;
        }

        memset(data, 0, sizeof(data));
        asc_hex("00112233445566778899AABBCCDDEEFF", data, 32);
        st = rf_read((HANDLE)icdev, 48, data);
        if(st == 0)
        {
                memset(temp, 0 ,sizeof(temp));
                hex_asc(data, temp, 16);
                infolist->AddItem("�����ݳɹ�",0);
                infolist->AddItem(AnsiString((char *)temp), 0);
        }
        else
        {
                infolist->AddItem("������ʧ��",0);
                return;
        }

        st = rf_initval((HANDLE)icdev, 48, 100);
        if(st == 0)
        {
                infolist->AddItem("��ʼ����ֵ100�ɹ�",0);
        }
        else
        {
                infolist->AddItem("��ʼ����ֵ100ʧ��",0);
                return;
        }

        st = rf_increment((HANDLE)icdev, 48, 200);
        if(st == 0)
        {
                infolist->AddItem("��ʼ����ֵ200�ɹ�",0);
        }
        else
        {
                infolist->AddItem("��ʼ����ֵ200ʧ��",0);
                return;
        }

        st = rf_decrement((HANDLE)icdev, 48, 100);
        if(st == 0)
        {
                infolist->AddItem("��ʼ����ֵ100�ɹ�",0);
        }
        else
        {
                infolist->AddItem("��ʼ����ֵ100ʧ��",0);
                return;
        }

        st = rf_readval((HANDLE)icdev, 48, &read_value);
        if(st == 0)
        {
                infolist->AddItem("����ֵ�ɹ�",0);
        }
        else
        {
                infolist->AddItem("����ֵʧ��",0);
                return;
        }
}
//---------------------------------------------------------------------------

//�ǽ�CPU��
void __fastcall TForm1::Button_cpuClick(TObject *Sender)
{
        int st,rLen = 0;
        unsigned char data[100] = {0};
        unsigned char temp[100] = {0};

        st = OpenCard((HANDLE)icdev, 0, data, temp, (unsigned char *)&rLen);
        if(st == 0)
        {
                memset(data, 0, sizeof(data));
                hex_asc(temp, data, rLen);
                infolist->AddItem("����ǽ�CPU���ɹ�",0);
                infolist->AddItem(AnsiString((char *)data), 0);
        }
        else
        {
                infolist->AddItem("����ǽ�CPU��ʧ��",0);
                return;
        }

        memset(data, 0, sizeof(data));
        memset(temp, 0, sizeof(temp));
        asc_hex("0084000008", data, 10);
        st = ExchangePro((HANDLE)icdev, data, 5, temp, (unsigned short *)&rLen);
        if(st == 0)
        {
                memset(data, 0, sizeof(data));
                hex_asc(temp, data, rLen);
                infolist->AddItem("�ǽ�CPU��ȡ������ɹ�",0);
                infolist->AddItem(AnsiString((char *)data), 0);
        }
        else
        {
                infolist->AddItem("�ǽ�CPU��ȡ�����ʧ��",0);
                return;
        }

}
//---------------------------------------------------------------------------

//�Ͽ�����
void __fastcall TForm1::Button_disconnectClick(TObject *Sender)
{
        int st = HB_Close();
        icdev = NULL;
        if(st == 0)
        {
                infolist->AddItem("�Ͽ����ӳɹ�",0);
        }
        else
        {
                infolist->AddItem("�Ͽ�����ʧ��",0);
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button_clearClick(TObject *Sender)
{
        infolist->Clear();        
}
//---------------------------------------------------------------------------

