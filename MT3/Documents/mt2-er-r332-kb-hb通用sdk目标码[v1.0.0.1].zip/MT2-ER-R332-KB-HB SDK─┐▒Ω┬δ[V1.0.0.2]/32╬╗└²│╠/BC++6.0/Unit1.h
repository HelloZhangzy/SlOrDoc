//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *Button_connect;
        TButton *Button_m1;
        TButton *Button_cpu;
        TButton *Button_disconnect;
        TButton *Button_clear;
        TListBox *infolist;
        void __fastcall Button_connectClick(TObject *Sender);
        void __fastcall Button_m1Click(TObject *Sender);
        void __fastcall Button_cpuClick(TObject *Sender);
        void __fastcall Button_disconnectClick(TObject *Sender);
        void __fastcall Button_clearClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
