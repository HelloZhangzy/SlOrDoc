#if !defined(AFX_ZX_32CTL_H__3D15ABE4_3A34_42D3_9ABD_BA482F3F4066__INCLUDED_)
#define AFX_ZX_32CTL_H__3D15ABE4_3A34_42D3_9ABD_BA482F3F4066__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Zx_32Ctl.h : Declaration of the CZx_32Ctrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl : See Zx_32Ctl.cpp for implementation.

//��ʼ����
#include <objsafe.h>
//��������



class CZx_32Ctrl : public COleControl
{
	DECLARE_DYNCREATE(CZx_32Ctrl)

	//��ʼ����
	DECLARE_INTERFACE_MAP()
	
	BEGIN_INTERFACE_PART(ObjSafe, IObjectSafety)
	STDMETHOD_(HRESULT, GetInterfaceSafetyOptions) ( 
	/* [in] */ REFIID riid,
	/* [out] */ DWORD __RPC_FAR *pdwSupportedOptions,
	/* [out] */ DWORD __RPC_FAR *pdwEnabledOptions
	);

STDMETHOD_(HRESULT, SetInterfaceSafetyOptions) ( 
	/* [in] */ REFIID riid,
	/* [in] */ DWORD dwOptionSetMask,
	/* [in] */ DWORD dwEnabledOptions
	);
	END_INTERFACE_PART(ObjSafe);
	//��������

// Constructor
public:
	CZx_32Ctrl();

	HANDLE		icdev;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZx_32Ctrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CZx_32Ctrl();

	DECLARE_OLECREATE_EX(CZx_32Ctrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CZx_32Ctrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CZx_32Ctrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CZx_32Ctrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CZx_32Ctrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CZx_32Ctrl)
	long m_lErrorCode;
	afx_msg void OnLErrorCodeChanged();
	afx_msg BSTR GetVersion(long icdev);
	afx_msg long DevBeep(long icdev, short nMsec, short nMsec_end, short nTime);
	afx_msg BSTR DevReadsnr(long icdev, short nSnrLen);
	afx_msg BSTR DevReadeeprom(long icdev, short nAddr, short nDLen);
	afx_msg long DevWriteeeprom(long icdev, short nAddr, short nDLen, LPCTSTR sWriteData);
	afx_msg BSTR HexAsc(LPCTSTR sHex, short ulLength);
	afx_msg BSTR AscHex(LPCTSTR sAsc, short ulLength);
	afx_msg BSTR OpenCard5(long icdev, short nMode);
	afx_msg BSTR RfCard(long icdev, short nMode);
	afx_msg long RfAuthenticationKey(long icdev, short nMode, short nBlockaddr, LPCTSTR sNkey);
	afx_msg BSTR RfRead(long icdev, short nAdr);
	afx_msg long RfWrite(long icdev, short nAdr, LPCTSTR sWriteData);
	afx_msg long RfInitval(long icdev, short nAdr, long ulValue);
	afx_msg long RfReadval(long icdev, short nAdr);
	afx_msg long RfIncrement(long icdev, short nAdr, long ulValue);
	afx_msg long RfDecrement(long icdev, short nAdr, long ulValue);
	afx_msg long RfTransfer(long icdev, short nAdr);
	afx_msg long RfRestore(long icdev, short nAdr);
	afx_msg long RfTerminal(long icdev);
	afx_msg BSTR ExchangeProHex(long icdev, LPCTSTR sCmd);
	afx_msg long HBOpen();
	afx_msg short HBClose();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CZx_32Ctrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CZx_32Ctrl)
	dispidLErrorCode = 1L,
	dispidGetVersion = 2L,
	dispidDevBeep = 3L,
	dispidDevReadsnr = 4L,
	dispidDevReadeeprom = 5L,
	dispidDevWriteeeprom = 6L,
	dispidHexAsc = 7L,
	dispidAscHex = 8L,
	dispidOpenCard5 = 9L,
	dispidRfCard = 10L,
	dispidRfAuthenticationKey = 11L,
	dispidRfRead = 12L,
	dispidRfWrite = 13L,
	dispidRfInitval = 14L,
	dispidRfReadval = 15L,
	dispidRfIncrement = 16L,
	dispidRfDecrement = 17L,
	dispidRfTransfer = 18L,
	dispidRfRestore = 19L,
	dispidRfTerminal = 20L,
	dispidExchangeProHex = 21L,
	dispidHBOpen = 22L,
	dispidHBClose = 23L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZX_32CTL_H__3D15ABE4_3A34_42D3_9ABD_BA482F3F4066__INCLUDED)
