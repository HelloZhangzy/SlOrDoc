// Zx_32Ctl.cpp : Implementation of the CZx_32Ctrl ActiveX Control class.

#include "stdafx.h"
#include "zx_32.h"
#include "Zx_32Ctl.h"
#include "Zx_32Ppg.h"
#include "mt_32.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define		PARAMETER_ERROR		-0x13
#define		HANDLE_ERROR		-0x12


IMPLEMENT_DYNCREATE(CZx_32Ctrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CZx_32Ctrl, COleControl)
	//{{AFX_MSG_MAP(CZx_32Ctrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CZx_32Ctrl, COleControl)
	//{{AFX_DISPATCH_MAP(CZx_32Ctrl)
	DISP_PROPERTY_NOTIFY(CZx_32Ctrl, "lErrorCode", m_lErrorCode, OnLErrorCodeChanged, VT_I4)
	DISP_FUNCTION(CZx_32Ctrl, "GetVersion", GetVersion, VT_BSTR, VTS_I4)
	DISP_FUNCTION(CZx_32Ctrl, "DevBeep", DevBeep, VT_I4, VTS_I4 VTS_I2 VTS_I2 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "DevReadsnr", DevReadsnr, VT_BSTR, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "DevReadeeprom", DevReadeeprom, VT_BSTR, VTS_I4 VTS_I2 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "DevWriteeeprom", DevWriteeeprom, VT_I4, VTS_I4 VTS_I2 VTS_I2 VTS_BSTR)
	DISP_FUNCTION(CZx_32Ctrl, "HexAsc", HexAsc, VT_BSTR, VTS_BSTR VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "AscHex", AscHex, VT_BSTR, VTS_BSTR VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "OpenCard5", OpenCard5, VT_BSTR, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "RfCard", RfCard, VT_BSTR, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "RfAuthenticationKey", RfAuthenticationKey, VT_I4, VTS_I4 VTS_I2 VTS_I2 VTS_BSTR)
	DISP_FUNCTION(CZx_32Ctrl, "RfRead", RfRead, VT_BSTR, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "RfWrite", RfWrite, VT_I4, VTS_I4 VTS_I2 VTS_BSTR)
	DISP_FUNCTION(CZx_32Ctrl, "RfInitval", RfInitval, VT_I4, VTS_I4 VTS_I2 VTS_I4)
	DISP_FUNCTION(CZx_32Ctrl, "RfReadval", RfReadval, VT_I4, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "RfIncrement", RfIncrement, VT_I4, VTS_I4 VTS_I2 VTS_I4)
	DISP_FUNCTION(CZx_32Ctrl, "RfDecrement", RfDecrement, VT_I4, VTS_I4 VTS_I2 VTS_I4)
	DISP_FUNCTION(CZx_32Ctrl, "RfTransfer", RfTransfer, VT_I4, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "RfRestore", RfRestore, VT_I4, VTS_I4 VTS_I2)
	DISP_FUNCTION(CZx_32Ctrl, "RfTerminal", RfTerminal, VT_I4, VTS_I4)
	DISP_FUNCTION(CZx_32Ctrl, "ExchangeProHex", ExchangeProHex, VT_BSTR, VTS_I4 VTS_BSTR)
	DISP_FUNCTION(CZx_32Ctrl, "HBOpen", HBOpen, VT_I4, VTS_NONE)
	DISP_FUNCTION(CZx_32Ctrl, "HBClose", HBClose, VT_I2, VTS_NONE)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CZx_32Ctrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CZx_32Ctrl, COleControl)
	//{{AFX_EVENT_MAP(CZx_32Ctrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CZx_32Ctrl, 1)
	PROPPAGEID(CZx_32PropPage::guid)
END_PROPPAGEIDS(CZx_32Ctrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CZx_32Ctrl, "ZX32.Zx32Ctrl.1",
	0x730bf2f0, 0xeae2, 0x46c5, 0xba, 0x6, 0x5a, 0xbf, 0xc9, 0xab, 0x8a, 0xa)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CZx_32Ctrl, _tlid, _wVerMajor, _wVerMinor)

//��ʼ����
/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::CA11CtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CZx_32Ctrl
/////////////////////////////////////////////////////////////////////////////
// Interface map for IObjectSafety
BEGIN_INTERFACE_MAP( CZx_32Ctrl, COleControl )
INTERFACE_PART(CZx_32Ctrl, IID_IObjectSafety, ObjSafe)
END_INTERFACE_MAP()
/////////////////////////////////////////////////////////////////////////////
// IObjectSafety member functions
// Delegate AddRef, Release, QueryInterface
ULONG FAR EXPORT CZx_32Ctrl::XObjSafe::AddRef()
{
    METHOD_PROLOGUE(CZx_32Ctrl, ObjSafe)
		return pThis->ExternalAddRef();
}
ULONG FAR EXPORT CZx_32Ctrl::XObjSafe::Release()
{
    METHOD_PROLOGUE(CZx_32Ctrl, ObjSafe)
		return pThis->ExternalRelease();
}
HRESULT FAR EXPORT CZx_32Ctrl::XObjSafe::QueryInterface(
														   REFIID iid, void FAR* FAR* ppvObj)
{
    METHOD_PROLOGUE(CZx_32Ctrl, ObjSafe)
		return (HRESULT)pThis->ExternalQueryInterface(&iid, ppvObj);
}
const DWORD dwSupportedBits = 
INTERFACESAFE_FOR_UNTRUSTED_CALLER |
INTERFACESAFE_FOR_UNTRUSTED_DATA;
const DWORD dwNotSupportedBits = ~ dwSupportedBits;

/////////////////////////////////////////////////////////////////////////////
// CStopLiteCtrl::XObjSafe::GetInterfaceSafetyOptions
// Allows container to query what interfaces are safe for what. We're
// optimizing significantly by ignoring which interface the caller is
// asking for.
HRESULT STDMETHODCALLTYPE 
CZx_32Ctrl::XObjSafe::GetInterfaceSafetyOptions( 
												   /* [in] */ REFIID riid,
												   /* [out] */ DWORD __RPC_FAR *pdwSupportedOptions,
												   /* [out] */ DWORD __RPC_FAR *pdwEnabledOptions)
{
	METHOD_PROLOGUE(CZx_32Ctrl, ObjSafe)
		HRESULT retval = ResultFromScode(S_OK);
	// does interface exist?
	IUnknown FAR* punkInterface;
	retval = pThis->ExternalQueryInterface(&riid, 
		(void * *)&punkInterface);
	if (retval != E_NOINTERFACE) { // interface exists
		punkInterface->Release(); // release it--just checking!
	}
	
	// we support both kinds of safety and have always both set,
	// regardless of interface
	*pdwSupportedOptions = *pdwEnabledOptions = dwSupportedBits;
	return retval; // E_NOINTERFACE if QI failed
}
/////////////////////////////////////////////////////////////////////////////
// CStopLiteCtrl::XObjSafe::SetInterfaceSafetyOptions
// Since we're always safe, this is a no-brainer--but we do check to make
// sure the interface requested exists and that the options we're asked to
// set exist and are set on (we don't support unsafe mode).
HRESULT STDMETHODCALLTYPE 
CZx_32Ctrl::XObjSafe::SetInterfaceSafetyOptions( 
												   /* [in] */ REFIID riid,
												   /* [in] */ DWORD dwOptionSetMask,
												   /* [in] */ DWORD dwEnabledOptions)
{
    METHOD_PROLOGUE(CZx_32Ctrl, ObjSafe)
		
		// does interface exist?
		IUnknown FAR* punkInterface;
	pThis->ExternalQueryInterface(&riid, (void * *)&punkInterface);
	if (punkInterface) { // interface exists
		punkInterface->Release(); // release it--just checking!
	}
	else { // interface doesn't exist
		return ResultFromScode(E_NOINTERFACE);
	}
	// can't set bits we don't support
	if (dwOptionSetMask & dwNotSupportedBits) { 
		return ResultFromScode(E_FAIL);
	}
	
	// can't set bits we do support to zero
	dwEnabledOptions &= dwSupportedBits;
	// (we already know there are no extra bits in mask )
	if ((dwOptionSetMask & dwEnabledOptions) !=
		dwOptionSetMask) {
		return ResultFromScode(E_FAIL);
	}        
	
	// don't need to change anything since we're always safe
	return ResultFromScode(S_OK);
}
//��������


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DZx_32 =
		{ 0xa6b799d6, 0x39c6, 0x43f5, { 0xb3, 0x36, 0x20, 0xa7, 0x46, 0x16, 0x6d, 0x32 } };
const IID BASED_CODE IID_DZx_32Events =
		{ 0x55623261, 0x6ca5, 0x4f00, { 0xbe, 0xb4, 0xee, 0xaa, 0xe0, 0xc1, 0x77, 0x39 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwZx_32OleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CZx_32Ctrl, IDS_ZX_32, _dwZx_32OleMisc)


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::CZx_32CtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CZx_32Ctrl

BOOL CZx_32Ctrl::CZx_32CtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_ZX_32,
			IDB_ZX_32,
			afxRegApartmentThreading,
			_dwZx_32OleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::CZx_32Ctrl - Constructor

CZx_32Ctrl::CZx_32Ctrl()
{
	InitializeIIDs(&IID_DZx_32, &IID_DZx_32Events);

	// TODO: Initialize your control's instance data here.

	icdev = NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::~CZx_32Ctrl - Destructor

CZx_32Ctrl::~CZx_32Ctrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::OnDraw - Drawing function

void CZx_32Ctrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::DoPropExchange - Persistence support

void CZx_32Ctrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::OnResetState - Reset control to default state

void CZx_32Ctrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl::AboutBox - Display an "About" box to the user

void CZx_32Ctrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_ZX_32);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32Ctrl message handlers

void CZx_32Ctrl::OnLErrorCodeChanged() 
{
	// TODO: Add notification handler code

	SetModifiedFlag();
}


BSTR CZx_32Ctrl::GetVersion(long icdev) 
{
	int st;
	unsigned char len = 0;
	unsigned char sVer[40];
	CString strResult;
	// TODO: Add your dispatch handler code here
	memset(sVer,0,sizeof(sVer));
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}
	
	st = get_version((HANDLE)icdev,&len,sVer);
	if (st != 0)
	{
		m_lErrorCode = st;
		return strResult.AllocSysString();
	}
	strResult = sVer;
	m_lErrorCode = 0;
	return strResult.AllocSysString();
}

long CZx_32Ctrl::DevBeep(long icdev, short nMsec, short nMsec_end, short nTime) 
{
	// TODO: Add your dispatch handler code here
	int st;
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}
	if (nMsec < 0 || nMsec_end < 0 || nTime < 0)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}
	
	st = dev_beep((HANDLE)icdev,nMsec,nMsec_end,nTime);
	if (st != 0)
	{
		m_lErrorCode = st;
	}
	else
		m_lErrorCode = 0;
	return m_lErrorCode;
}


BSTR CZx_32Ctrl::DevReadsnr(long icdev, short nSnrLen) 
{
	int st;
	char snr[40];
	CString strResult;
	// TODO: Add your dispatch handler code here
	memset(snr,0,sizeof(snr));
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}

	if (nSnrLen <= 0 || nSnrLen > 20)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}
	
	st = dev_readsnr((HANDLE)icdev,nSnrLen,snr);
	if (st != 0)
	{
		m_lErrorCode = st;
		return strResult.AllocSysString();
	}
	strResult = snr;
	m_lErrorCode = 0;
	return strResult.AllocSysString();
}

BSTR CZx_32Ctrl::DevReadeeprom(long icdev, short nAddr, short nDLen) 
{
	int st;
	unsigned char sRecvData[400];
	unsigned char sReadData[800];
	CString strResult;
	// TODO: Add your dispatch handler code here
	memset(sRecvData,0,sizeof(sRecvData));
	memset(sReadData,0,sizeof(sReadData));
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}
	
	if (nAddr < 0 || nAddr > 199 || nDLen < 1 || nDLen > 200 || (nAddr + nDLen) > 200)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}
	
	st = dev_readeeprom((HANDLE)icdev,nAddr,nDLen,sRecvData);
	if (st == 0)
	{
		hex_asc(sRecvData,sReadData,nDLen);
		strResult = sReadData;
	}
	
	m_lErrorCode = st;
	return strResult.AllocSysString();
}

long CZx_32Ctrl::DevWriteeeprom(long icdev, short nAddr, short nDLen, LPCTSTR sWriteData) 
{
	// TODO: Add your dispatch handler code here
	int st;
	unsigned char sWrite[210];
	memset(sWrite,0,sizeof(sWrite));
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}
	
	if (nAddr < 0 || nAddr > 199 || nDLen < 1 || nDLen > 200 || (nAddr + nDLen) > 200 || strlen((char *)sWriteData) != nDLen*2)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}
	asc_hex((unsigned char *)sWriteData,sWrite,nDLen*2);
	st = dev_writeeeprom((HANDLE)icdev,nAddr,nDLen,(unsigned char *)sWrite);
	
	m_lErrorCode = st;
	return st;
}



BSTR CZx_32Ctrl::HexAsc(LPCTSTR sHex, short ulLength) 
{
	int st;
	unsigned char asc[3000];
	CString strResult;
	// TODO: Add your dispatch handler code here
	memset(asc,0,sizeof(asc));
	
	if (ulLength < 0)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}

	st = hex_asc((unsigned char *)sHex,asc,ulLength);
	
	m_lErrorCode = st;
	strResult = asc;
	
	return strResult.AllocSysString();
}

BSTR CZx_32Ctrl::AscHex(LPCTSTR sAsc, short ulLength) 
{
	int st;
	unsigned char hex[3000];
	CString strResult;
	// TODO: Add your dispatch handler code here
	memset(hex,0,sizeof(hex));
	
	if (ulLength < 0)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}
	st = asc_hex((unsigned char *)sAsc,hex,ulLength);
	
	m_lErrorCode = st;
	strResult = hex;
	
	return strResult.AllocSysString();
}


BSTR CZx_32Ctrl::OpenCard5(long icdev, short nMode) 
{
	int st;
	unsigned char snr[20];
	unsigned char atr[40];
	unsigned char atr1[80];
	unsigned char rLen = 0;
	CString strResult;
	memset(snr,0,sizeof(snr));
	memset(atr,0,sizeof(atr));
	memset(atr1,0,sizeof(atr1));
	// TODO: Add your dispatch handler code here
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}

	if ((nMode != 0 && nMode != 1))
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}

	st = OpenCard((HANDLE)icdev,nMode,snr,atr,&rLen);
	if (st == 0)
	{
		hex_asc(atr,atr1,rLen);
		strResult = atr1;
	}
	m_lErrorCode = st;
	
	return strResult.AllocSysString();
}


BSTR CZx_32Ctrl::ExchangeProHex(long icdev, LPCTSTR sCmd) 
{
	int st;
	unsigned char sWriteData[300];
	unsigned char sReadData[300];
	unsigned char sReadData1[600];
	unsigned char rLen = 0;
	CString strResult;
	
	memset(sWriteData,0,sizeof(sWriteData));
	memset(sReadData,0,sizeof(sReadData));
	memset(sReadData1,0,sizeof(sReadData1));
	// TODO: Add your dispatch handler code here
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}
	
	st = ExchangePro_hex((HANDLE)icdev,(char *)sCmd,(char *)sReadData);
	if (st == 0)
	{
//		hex_asc(sReadData,sReadData1,strlen((char *)sReadData));
		strResult = sReadData;
	}
	m_lErrorCode = st;
	
	return strResult.AllocSysString();
}


BSTR CZx_32Ctrl::RfCard(long icdev, short nMode) 
{
	int st;
	unsigned char atr[40];
	unsigned char atr1[40];
	memset(atr,0,sizeof(atr));
	memset(atr1,0,sizeof(atr1));
	CString strResult;
	// TODO: Add your dispatch handler code here

	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}

	if (nMode != 0 && nMode != 1)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}

	st = rf_card((HANDLE)icdev,nMode,atr);
	if (st == 0)
	{
		hex_asc(atr,atr1,4);
		strResult = atr1;
	}

	m_lErrorCode = st;

	return strResult.AllocSysString();
}

long CZx_32Ctrl::RfAuthenticationKey(long icdev, short nMode, short nBlockaddr, LPCTSTR sNkey) 
{
	// TODO: Add your dispatch handler code here
	int st;
	unsigned char key[20];
	memset(key,0,sizeof(key));
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}

	if ((nMode != 0 && nMode != 1) || nBlockaddr < 0 || nBlockaddr > 255 || strlen((char *)sNkey) != 12)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}

	asc_hex((unsigned char *)sNkey,key,12);

	st = rf_authentication_key((HANDLE)icdev,nMode,nBlockaddr,key);
	m_lErrorCode = st;
	return st;
}

BSTR CZx_32Ctrl::RfRead(long icdev, short nAdr) 
{
	int st;
	unsigned char sReadData[30];
	unsigned char sReadData1[60];
	memset(sReadData,0,sizeof(sReadData));
	memset(sReadData1,0,sizeof(sReadData1));
	CString strResult;
	// TODO: Add your dispatch handler code here

	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return strResult.AllocSysString();
	}
	
	if (nAdr < 0 || nAdr > 255)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return strResult.AllocSysString();
	}

	
	st = rf_read((HANDLE)icdev,nAdr,sReadData);
	if (st == 0)
	{
		hex_asc(sReadData,sReadData1,16);
		strResult = sReadData1;
	}

	m_lErrorCode = st;
	return strResult.AllocSysString();
}

long CZx_32Ctrl::RfWrite(long icdev, short nAdr, LPCTSTR sWriteData) 
{
	// TODO: Add your dispatch handler code here
	int st;
	unsigned char tempbuffer[30];
	memset(tempbuffer,0,sizeof(tempbuffer));

	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}

	if (nAdr < 0 || nAdr > 255 || strlen((char *)sWriteData) != 32)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}

	asc_hex((unsigned char *)sWriteData,tempbuffer,32);

	st = rf_write((HANDLE)icdev,nAdr,tempbuffer);

	m_lErrorCode = st;
	return st;
}

long CZx_32Ctrl::RfInitval(long icdev, short nAdr, long ulValue) 
{
	// TODO: Add your dispatch handler code here
	int st;
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}

	if (nAdr < 0 || nAdr > 255 || ulValue < 0)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}

	st = rf_initval((HANDLE)icdev,nAdr,ulValue);

	m_lErrorCode = st;
	return st;
}

long CZx_32Ctrl::RfReadval(long icdev, short nAdr) 
{
	// TODO: Add your dispatch handler code here
	int st;
	unsigned long myvalue = 0;

	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}

	if (nAdr < 0 || nAdr > 255)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}

	st = rf_readval((HANDLE)icdev,nAdr,&myvalue);

	m_lErrorCode = st;
	return myvalue;
}

long CZx_32Ctrl::RfIncrement(long icdev, short nAdr, long ulValue) 
{
	// TODO: Add your dispatch handler code here
	int st;
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}
	
	if (nAdr < 0 || nAdr > 255 || ulValue < 0)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}
	
	st = rf_increment((HANDLE)icdev,nAdr,ulValue);
	
	m_lErrorCode = st;
	return st;
}

long CZx_32Ctrl::RfDecrement(long icdev, short nAdr, long ulValue) 
{
	// TODO: Add your dispatch handler code here
	int st;
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}
	
	if (nAdr < 0 || nAdr > 255 || ulValue < 0)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}
	
	st = rf_decrement((HANDLE)icdev,nAdr,ulValue);
	
	m_lErrorCode = st;
	return st;
}

long CZx_32Ctrl::RfTransfer(long icdev, short nAdr) 
{
	// TODO: Add your dispatch handler code here
	int st;
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}
	
	if (nAdr < 0 || nAdr > 255)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}
	
	st = rf_transfer((HANDLE)icdev,nAdr);
	
	m_lErrorCode = st;
	return st;
}

long CZx_32Ctrl::RfRestore(long icdev, short nAdr) 
{
	// TODO: Add your dispatch handler code here
	int st;
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}
	
	if (nAdr < 0 || nAdr > 255)
	{
		m_lErrorCode = PARAMETER_ERROR;
		return m_lErrorCode;
	}
	
	st = rf_restore((HANDLE)icdev,nAdr);
	
	m_lErrorCode = st;
	return st;
}

long CZx_32Ctrl::RfTerminal(long icdev) 
{
	// TODO: Add your dispatch handler code here
	int st;
	
	if (icdev < 0)
	{
		m_lErrorCode = HANDLE_ERROR;
		return m_lErrorCode;
	}

	st = rf_terminal((HANDLE)icdev);
	
	m_lErrorCode = st;
	return st;
}


long CZx_32Ctrl::HBOpen() 
{
	// TODO: Add your dispatch handler code here
	if (icdev > 0)
	{
		HB_Close();
		icdev = NULL;
	}

	icdev = HB_Open();
	if (icdev > 0)
	{
		m_lErrorCode = 0;
	}
	else
		m_lErrorCode = -1;
	return (long)icdev;
}

short CZx_32Ctrl::HBClose() 
{
	// TODO: Add your dispatch handler code here

	int st = HB_Close();
	icdev = NULL;
	return st;
}
