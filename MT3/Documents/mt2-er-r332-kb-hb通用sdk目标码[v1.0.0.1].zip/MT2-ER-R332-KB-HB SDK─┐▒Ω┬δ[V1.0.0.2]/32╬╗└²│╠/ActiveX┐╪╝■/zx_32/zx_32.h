#if !defined(AFX_ZX_32_H__4533867C_0CD4_43D9_90D4_1989EC9AC306__INCLUDED_)
#define AFX_ZX_32_H__4533867C_0CD4_43D9_90D4_1989EC9AC306__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// zx_32.h : main header file for ZX_32.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CZx_32App : See zx_32.cpp for implementation.

class CZx_32App : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZX_32_H__4533867C_0CD4_43D9_90D4_1989EC9AC306__INCLUDED)
