#if !defined(AFX_ZX_32PPG_H__DEEDA990_7097_4D5C_8DBE_6AC17E459791__INCLUDED_)
#define AFX_ZX_32PPG_H__DEEDA990_7097_4D5C_8DBE_6AC17E459791__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Zx_32Ppg.h : Declaration of the CZx_32PropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CZx_32PropPage : See Zx_32Ppg.cpp.cpp for implementation.

class CZx_32PropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CZx_32PropPage)
	DECLARE_OLECREATE_EX(CZx_32PropPage)

// Constructor
public:
	CZx_32PropPage();

// Dialog Data
	//{{AFX_DATA(CZx_32PropPage)
	enum { IDD = IDD_PROPPAGE_ZX_32 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CZx_32PropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZX_32PPG_H__DEEDA990_7097_4D5C_8DBE_6AC17E459791__INCLUDED)
