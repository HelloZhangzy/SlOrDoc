// Zx_32Ppg.cpp : Implementation of the CZx_32PropPage property page class.

#include "stdafx.h"
#include "zx_32.h"
#include "Zx_32Ppg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CZx_32PropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CZx_32PropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CZx_32PropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CZx_32PropPage, "ZX32.Zx32PropPage.1",
	0x6dbb99af, 0x3345, 0x4a38, 0xa8, 0xed, 0x7e, 0x8d, 0xad, 0x1d, 0xd7, 0x70)


/////////////////////////////////////////////////////////////////////////////
// CZx_32PropPage::CZx_32PropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CZx_32PropPage

BOOL CZx_32PropPage::CZx_32PropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_ZX_32_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32PropPage::CZx_32PropPage - Constructor

CZx_32PropPage::CZx_32PropPage() :
	COlePropertyPage(IDD, IDS_ZX_32_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CZx_32PropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32PropPage::DoDataExchange - Moves data between page and properties

void CZx_32PropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CZx_32PropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CZx_32PropPage message handlers
