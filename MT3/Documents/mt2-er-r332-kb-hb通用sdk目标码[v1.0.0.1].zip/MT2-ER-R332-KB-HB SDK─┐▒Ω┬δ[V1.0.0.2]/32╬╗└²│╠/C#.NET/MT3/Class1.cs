using System;
using System.Collections.Generic;
using System.Text;

namespace MT3
{
    class Class1
    {
    }
}
