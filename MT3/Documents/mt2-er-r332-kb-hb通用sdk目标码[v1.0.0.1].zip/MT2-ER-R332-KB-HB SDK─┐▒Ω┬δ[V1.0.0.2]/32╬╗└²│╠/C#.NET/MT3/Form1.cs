﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MT3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int icdev;   // 通讯设备标识符
        public short st;    //函数返回值

        private void BTConnect_Click(object sender, EventArgs e)
        {
            if (icdev > 1)
            {
                st = mt_32dll.HB_Close();
            }
            int i;
            for (i = 0; i < 100; i++)
            {
                icdev = mt_32dll.HB_Open();
                mt_32dll.HB_Close();
            }
            icdev = mt_32dll.HB_Open();
            if (icdev > 1)
                listInfo.Items.Insert(0, "连接成功!");
            else
                listInfo.Items.Insert(0, "连接失败!");
        }
       
     
        private void BTBreak_Click(object sender, EventArgs e)
        {
            st = mt_32dll.HB_Close();
            if (st != 0)
            {
                listInfo.Items.Insert(0, "断开连接失败!");
            }
            else
            {
                icdev = 0;
                listInfo.Items.Insert(0, "断开连接成功!");
            }
        }

        private void BTClear_Click(object sender, EventArgs e)
        {
            listInfo.Items.Clear();
        }

        private void listInfo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BTM1Card_Click(object sender, EventArgs e)
        {
            byte[] key = new byte[10];
            byte[] sRecData = new byte[20];
            byte[] RecData = new byte[40];

            //byte[] WriteData = new byte[5];

            byte[] WriteData1 = new byte[20];
            byte[] d = new byte[40];
            byte[] rlen = new byte[8];
            byte[] datarecv = new byte[1000];
            byte[] datarecvasc = new byte[1000];
            long[] val = new long[10];




            WriteData1[0] = 0x00;
            WriteData1[1] = 0x01;
            WriteData1[2] = 0x02;
            WriteData1[3] = 0x03;
            WriteData1[4] = 0x04;
            WriteData1[5] = 0x05;
            WriteData1[6] = 0x06;
            WriteData1[7] = 0x07;
            WriteData1[8] = 0x08;
            WriteData1[9] = 0x09;
            WriteData1[10] = 0x0a;
            WriteData1[11] = 0x0b;
            WriteData1[12] = 0x0c;
            WriteData1[13] = 0x0d;
            WriteData1[14] = 0x0e;
            WriteData1[15] = 0x0f;

            st = mt_32dll.rf_card(icdev, 0,datarecv ,rlen);
            if (st != 0)
                listInfo.Items.Insert(0, "M1卡寻卡失败!");
            else
                listInfo.Items.Insert(0, "M1卡寻卡成功!");

            key[0] = 0xff;
            key[1] = 0xff;
            key[2] = 0xff;
            key[3] = 0xff;
            key[4] = 0xff;
            key[5] = 0xff;
            st = mt_32dll.rf_authentication_key(icdev, 0,48,key);
            if (st != 0)
                listInfo.Items.Insert(0, "M1卡密码认证失败!");
            else
                listInfo.Items.Insert(0, "M1卡密码认证成功!");


            st = mt_32dll.rf_read(icdev,48,sRecData);
            if (st != 0)
                listInfo.Items.Insert(0,"M1卡读数据失败!");
            else
            {
                mt_32dll.hex_asc(sRecData, RecData, 16);
                listInfo.Items.Insert(0, "M1卡读数据成功,数据:");
                listInfo.Items.Insert(0, Encoding.Default.GetString(RecData));
            };
            st = mt_32dll.rf_write(icdev, 48, WriteData1);
            if (st != 0)
                listInfo.Items.Insert(0, "M1卡写数据失败!");
            else
                listInfo.Items.Insert(0, "M1卡写数据成功!");

            st = mt_32dll.rf_initval(icdev, 48, 100);
            if (st != 0)
                listInfo.Items.Insert(0, "M1卡初始化失败!");
            else
                listInfo.Items.Insert(0, "M1卡初始化成功!");

            st = mt_32dll.rf_decrement(icdev, 48, 10);
            if (st != 0)
                listInfo.Items.Insert(0,"M1卡减值失败!");
            else
                listInfo.Items.Insert(0, "M1卡减值成功!");

            st = mt_32dll.rf_increment(icdev, 48, 10);
            if (st != 0)
                listInfo.Items.Insert(0, "M1卡加值失败!");
            else
                listInfo.Items.Insert(0, "M1卡加值成功!");

            st = mt_32dll.rf_readval(icdev, 48, val);
            if (st != 0)
                listInfo.Items.Insert(0, "M1卡读值失败!");
            else
                listInfo.Items.Insert(0, "M1卡读值成功!");

        }

        private void BTFCPU_Click(object sender, EventArgs e)
        {
            byte[] rlen2 = new byte[10];
            byte[] snr = new byte[100];
            byte[] rlen = new byte[10];
            byte[] data1 = new byte[200];
            byte[] senddata = new byte[6];   //{0x00,0x84,0x00,0x00,0x08,0};   //获取随机数
            byte[] datarecv = new byte[300];
            byte[] datarecvasc = new byte[600];
            byte[] dataa1 = new byte[400];
            byte[] cardinfo = new byte[100];
            byte[] recdata = new byte[100];
            byte[] cardinfolen = new byte[10];
            byte[] recdataasc = new byte[200];
            //mt_32dll.rf_card(icdev, 0, recdata,cardinfolen);

            st=mt_32dll.OpenCard(icdev, 0, snr, data1, rlen2);
            if (st != 0)
            {
                listInfo.Items.Insert(0, "非接CPU卡打开失败!");
            }
            else
            {
                st = mt_32dll.hex_asc(data1, dataa1, BitConverter.ToUInt64(rlen2, 0));
                listInfo.Items.Insert(0, "非接CPU卡打开成功,复位信息:");
                listInfo.Items.Insert(0, Encoding.Default.GetString(dataa1));
            }

            //获取随机数
            senddata[0] = 0;
            senddata[1] = 132;
            senddata[2] = 0;
            senddata[3] = 0;
            senddata[4] = 8;
            senddata[5] = 0;
            st = mt_32dll.ExchangePro(icdev, senddata, 5, datarecv, rlen);
            if (st != 0)
            {
                listInfo.Items.Insert(0, "非接CPU卡取随机数失败!");
            }
            else
            {
                st = mt_32dll.hex_asc(datarecv, datarecvasc, BitConverter.ToUInt64(rlen, 0));
                listInfo.Items.Insert(0, "非接CPU卡取随机数成功,随机数:");
                listInfo.Items.Insert(0, Encoding.Default.GetString(datarecvasc));
            }

            st = mt_32dll.CloseCard(icdev);
            if (st != 0)
                listInfo.Items.Insert(0, "非接CPU卡关闭失败!");
            else
                listInfo.Items.Insert(0, "非接CPU卡关闭成功!");

        }

    }
}