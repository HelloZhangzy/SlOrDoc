﻿namespace MT3
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BTConnect = new System.Windows.Forms.Button();
            this.BTBreak = new System.Windows.Forms.Button();
            this.BTClear = new System.Windows.Forms.Button();
            this.listInfo = new System.Windows.Forms.ListBox();
            this.BTM1Card = new System.Windows.Forms.Button();
            this.BTFCPU = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BTConnect
            // 
            this.BTConnect.Location = new System.Drawing.Point(21, 23);
            this.BTConnect.Name = "BTConnect";
            this.BTConnect.Size = new System.Drawing.Size(75, 23);
            this.BTConnect.TabIndex = 0;
            this.BTConnect.Text = "建立连接";
            this.BTConnect.UseVisualStyleBackColor = true;
            this.BTConnect.Click += new System.EventHandler(this.BTConnect_Click);
            // 
            // BTBreak
            // 
            this.BTBreak.Location = new System.Drawing.Point(21, 160);
            this.BTBreak.Name = "BTBreak";
            this.BTBreak.Size = new System.Drawing.Size(75, 23);
            this.BTBreak.TabIndex = 4;
            this.BTBreak.Text = "断开连接";
            this.BTBreak.UseVisualStyleBackColor = true;
            this.BTBreak.Click += new System.EventHandler(this.BTBreak_Click);
            // 
            // BTClear
            // 
            this.BTClear.Location = new System.Drawing.Point(21, 211);
            this.BTClear.Name = "BTClear";
            this.BTClear.Size = new System.Drawing.Size(75, 23);
            this.BTClear.TabIndex = 5;
            this.BTClear.Text = "清除信息";
            this.BTClear.UseVisualStyleBackColor = true;
            this.BTClear.Click += new System.EventHandler(this.BTClear_Click);
            // 
            // listInfo
            // 
            this.listInfo.FormattingEnabled = true;
            this.listInfo.ItemHeight = 12;
            this.listInfo.Location = new System.Drawing.Point(111, 23);
            this.listInfo.Name = "listInfo";
            this.listInfo.Size = new System.Drawing.Size(333, 220);
            this.listInfo.TabIndex = 6;
            this.listInfo.SelectedIndexChanged += new System.EventHandler(this.listInfo_SelectedIndexChanged);
            // 
            // BTM1Card
            // 
            this.BTM1Card.Location = new System.Drawing.Point(21, 67);
            this.BTM1Card.Name = "BTM1Card";
            this.BTM1Card.Size = new System.Drawing.Size(75, 23);
            this.BTM1Card.TabIndex = 7;
            this.BTM1Card.Text = "M1卡";
            this.BTM1Card.UseVisualStyleBackColor = true;
            this.BTM1Card.Click += new System.EventHandler(this.BTM1Card_Click);
            // 
            // BTFCPU
            // 
            this.BTFCPU.Location = new System.Drawing.Point(21, 112);
            this.BTFCPU.Name = "BTFCPU";
            this.BTFCPU.Size = new System.Drawing.Size(75, 23);
            this.BTFCPU.TabIndex = 8;
            this.BTFCPU.Text = "非接CPU卡";
            this.BTFCPU.UseVisualStyleBackColor = true;
            this.BTFCPU.Click += new System.EventHandler(this.BTFCPU_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 261);
            this.Controls.Add(this.BTFCPU);
            this.Controls.Add(this.BTM1Card);
            this.Controls.Add(this.listInfo);
            this.Controls.Add(this.BTClear);
            this.Controls.Add(this.BTBreak);
            this.Controls.Add(this.BTConnect);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C#例程";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTConnect;
        private System.Windows.Forms.Button BTBreak;
        private System.Windows.Forms.Button BTClear;
        private System.Windows.Forms.ListBox listInfo;
        private System.Windows.Forms.Button BTM1Card;
        private System.Windows.Forms.Button BTFCPU;
    }
}

